#pragma once

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct seed_log_writer seed_log_writer_t;

seed_log_writer_t* seed_log_open(const char* path);
seed_log_writer_t* seed_log_wrap(void* stream);
void seed_log_set_default(seed_log_writer_t* writer);
seed_log_writer_t* seed_log_default(void);
void seed_log_emit(seed_log_writer_t* writer,
                   const char* level,
                   const char* component,
                   const char* message,
                   const char* const* keys,
                   const char* const* values,
                   size_t count);
void seed_log_emit_simple(seed_log_writer_t* writer,
                          const char* level,
                          const char* component,
                          const char* message);
void seed_log_flush(seed_log_writer_t* writer);
void seed_log_close(seed_log_writer_t* writer);

#ifdef __cplusplus
}
#endif

