#include "core/util/log.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

struct seed_log_writer {
    FILE* stream;
    bool owned;
};

static seed_log_writer_t* g_default_writer = NULL;

static void json_escape(FILE* fp, const char* input) {
    if (!input) {
        fputs("null", fp);
        return;
    }
    fputc('"', fp);
    for (const unsigned char* c = (const unsigned char*)input; *c; ++c) {
        switch (*c) {
            case '"':  fputs("\\\"", fp); break;
            case '\\': fputs("\\\\", fp); break;
            case '\b': fputs("\\b", fp);  break;
            case '\f': fputs("\\f", fp);  break;
            case '\n': fputs("\\n", fp);  break;
            case '\r': fputs("\\r", fp);  break;
            case '\t': fputs("\\t", fp);  break;
            default:
                if (*c < 0x20) {
                    fprintf(fp, "\\u%04x", *c);
                } else {
                    fputc(*c, fp);
                }
        }
    }
    fputc('"', fp);
}

static seed_log_writer_t* allocate_writer(FILE* stream, bool owned) {
    if (!stream) {
        return NULL;
    }
    seed_log_writer_t* writer = (seed_log_writer_t*)calloc(1, sizeof(*writer));
    if (!writer) {
        return NULL;
    }
    writer->stream = stream;
    writer->owned = owned;
    return writer;
}

seed_log_writer_t* seed_log_open(const char* path) {
    if (!path) {
        return allocate_writer(stdout, false);
    }
    FILE* fp = fopen(path, "a");
    if (!fp) {
        return NULL;
    }
    return allocate_writer(fp, true);
}

seed_log_writer_t* seed_log_wrap(void* stream) {
    return allocate_writer((FILE*)stream, false);
}

void seed_log_set_default(seed_log_writer_t* writer) {
    g_default_writer = writer;
}

seed_log_writer_t* seed_log_default(void) {
    return g_default_writer;
}

static seed_log_writer_t* pick_writer(seed_log_writer_t* writer) {
    if (writer) {
        return writer;
    }
    if (g_default_writer) {
        return g_default_writer;
    }
    g_default_writer = allocate_writer(stdout, false);
    return g_default_writer;
}

void seed_log_emit(seed_log_writer_t* writer,
                   const char* level,
                   const char* component,
                   const char* message,
                   const char* const* keys,
                   const char* const* values,
                   size_t count) {
    seed_log_writer_t* target = pick_writer(writer);
    if (!target || !target->stream) {
        return;
    }

    FILE* fp = target->stream;
    const time_t now = time(NULL);

    fputc('{', fp);
    fputs("\"ts\":", fp);
    fprintf(fp, "%ld", (long)now);
    fputs(",\"level\":", fp);
    json_escape(fp, level ? level : "INFO");
    fputs(",\"component\":", fp);
    json_escape(fp, component ? component : "seed");
    fputs(",\"msg\":", fp);
    json_escape(fp, message ? message : "");

    for (size_t i = 0; i < count; ++i) {
        const char* key = keys ? keys[i] : NULL;
        const char* value = values ? values[i] : NULL;
        if (!key || !*key) {
            continue;
        }
        fputc(',', fp);
        json_escape(fp, key);
        fputc(':', fp);
        json_escape(fp, value);
    }

    fputs("}\n", fp);
}

void seed_log_emit_simple(seed_log_writer_t* writer,
                          const char* level,
                          const char* component,
                          const char* message) {
    seed_log_emit(writer, level, component, message, NULL, NULL, 0);
}

void seed_log_flush(seed_log_writer_t* writer) {
    seed_log_writer_t* target = pick_writer(writer);
    if (target && target->stream) {
        fflush(target->stream);
    }
}

void seed_log_close(seed_log_writer_t* writer) {
    if (!writer) {
        return;
    }
    if (writer->stream && writer->owned) {
        fflush(writer->stream);
        fclose(writer->stream);
    }
    if (g_default_writer == writer) {
        g_default_writer = NULL;
    }
    free(writer);
}

