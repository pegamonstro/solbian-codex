#!/bin/sh
# Minimal placeholder health check until daemons expose HTTP endpoints.

set -eu

ROOT="$(cd "$(dirname "$0")/.." && pwd)"

services="seednetd seedfsd seedpoold orchestrator metricsd"

for svc in $services; do
    bin_path="$ROOT/services/$svc/$svc"
    if [ ! -x "$bin_path" ]; then
        echo "WARN: $svc binary not yet available at $bin_path" >&2
    else
        echo "INFO: $svc binary present."
    fi
done

echo "health_check: pending real integration"
