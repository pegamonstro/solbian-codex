#include <stdio.h>
#include <string.h>

/* Forward declaration from core/net once implemented. */
int seed_net_validate_hello(const unsigned char* payload,
                            size_t payload_len,
                            char* reason,
                            size_t reason_len);

int main(void) {
    /* Intentionally short frame to ensure validation catches length issues. */
    const unsigned char malformed[] = {0x01, 0x02, 0x03};
    char reason[128] = {0};

    int rc = seed_net_validate_hello(malformed, sizeof(malformed), reason, sizeof(reason));
    if (rc == 0) {
        fprintf(stderr, "seed_net_validate_hello unexpectedly accepted malformed payload\n");
        return 1;
    }

    if (reason[0] != '\0') {
        fprintf(stdout, "reject_reason=%s\n", reason);
    } else {
        fprintf(stdout, "reject_reason=(empty)\n");
    }
    return 0;
}

