#!/bin/sh
set -eu

if [ $# -lt 1 ]; then
    echo "usage: $(basename "$0") <daemon> [--junit <file>] [extra args...]" >&2
    exit 1
fi

DAEMON="$1"
shift

JUNIT_FILE=""
EXTRA_ARGS=""

while [ $# -gt 0 ]; do
    case "$1" in
        --junit)
            if [ $# -lt 2 ]; then
                echo "missing value for --junit" >&2
                exit 1
            fi
            JUNIT_FILE="$2"
            shift 2
            ;;
        --)
            shift
            if [ $# -gt 0 ]; then
                EXTRA_ARGS="$EXTRA_ARGS $*"
            fi
            break
            ;;
        *)
            EXTRA_ARGS="$EXTRA_ARGS $1"
            shift
            ;;
    esac
done

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="${SEED_BUILD_DIR:-$ROOT/build}"
BIN_ROOT="${SEED_BIN_ROOT:-$BUILD_DIR}"
CACHE="$BUILD_DIR/CMakeCache.txt"
CONFIG_HINT="${SEED_BUILD_CONFIG:-}"

if [ -z "$CONFIG_HINT" ] && [ -f "$CACHE" ]; then
    CONFIG_HINT="$(sed -n 's/^CMAKE_BUILD_TYPE:STRING=//p' "$CACHE")"
fi

if [ -z "$CONFIG_HINT" ]; then
    CONFIG_HINT="RelWithDebInfo"
fi

DATA_ROOT="$BUILD_DIR/daemon_health"
DATA_DIR="$DATA_ROOT/$DAEMON"
LOG="$DATA_DIR/${DAEMON}.log"

compute_duration() {
    end_time=$(date +%s 2>/dev/null || echo 0)
    duration=$((end_time - start_time))
    if [ "$duration" -lt 0 ]; then
        duration=0
    fi
    DURATION_STR=$(printf "%d" "$duration")
}

write_junit_success() {
    [ -z "$JUNIT_FILE" ] && return 0
    compute_duration
    mkdir -p "$(dirname "$JUNIT_FILE")"
    cat <<EOF >"$JUNIT_FILE"
<?xml version="1.0" encoding="UTF-8"?>
<testsuite name="daemon_health" tests="1" failures="0" time="$DURATION_STR">
  <testcase classname="daemon_health" name="$DAEMON" time="$DURATION_STR"/>
</testsuite>
EOF
}

write_junit_failure() {
    [ -z "$JUNIT_FILE" ] && return 0
    message="$1"
    log_snip="$2"
    compute_duration
    mkdir -p "$(dirname "$JUNIT_FILE")"
    cat <<EOF >"$JUNIT_FILE"
<?xml version="1.0" encoding="UTF-8"?>
<testsuite name="daemon_health" tests="1" failures="1" time="$DURATION_STR">
  <testcase classname="daemon_health" name="$DAEMON" time="$DURATION_STR">
    <failure message="$message"><![CDATA[$log_snip]]></failure>
  </testcase>
</testsuite>
EOF
}

cleanup() {
    if [ -n "${DAEMON_PID:-}" ] && kill -0 "$DAEMON_PID" 2>/dev/null; then
        kill "$DAEMON_PID" 2>/dev/null || true
        wait "$DAEMON_PID" 2>/dev/null || true
    fi
}

fail() {
    message="$1"
    log_snip="$2"
    write_junit_failure "$message" "$log_snip"
    printf '%s\n' "$message" >&2
    if [ -n "$log_snip" ]; then
        printf '%s\n' "$log_snip" >&2
    fi
    exit 1
}

trap cleanup EXIT INT TERM

find_binary() {
    name="$1"
    shift
    for path in "$@"; do
        if [ -n "$path" ] && [ -x "$path" ]; then
            echo "$path"
            return 0
        fi
    done
    if command -v find >/dev/null 2>&1; then
        candidate="$(find "$BIN_ROOT" -maxdepth 5 -type f -name "$name" -perm -111 2>/dev/null | head -n 1)"
        if [ -z "$candidate" ] && [ "$BIN_ROOT" != "$BUILD_DIR" ]; then
            candidate="$(find "$BUILD_DIR" -maxdepth 5 -type f -name "$name" -perm -111 2>/dev/null | head -n 1)"
        fi
        if [ -n "$candidate" ] && [ -x "$candidate" ]; then
            echo "$candidate"
            return 0
        fi
    fi
    return 1
}

BIN_CANDIDATES="
$BIN_ROOT/$DAEMON
$BIN_ROOT/$DAEMON/$DAEMON
$BIN_ROOT/services/$DAEMON/$DAEMON
$BIN_ROOT/services/$DAEMON/$CONFIG_HINT/$DAEMON
$BIN_ROOT/$CONFIG_HINT/$DAEMON
$BIN_ROOT/$CONFIG_HINT/services/$DAEMON/$DAEMON
$BUILD_DIR/services/$DAEMON/$CONFIG_HINT/$DAEMON
$BUILD_DIR/$CONFIG_HINT/$DAEMON
$BUILD_DIR/$DAEMON
"

DAEMON_BIN="${DAEMON_BIN:-}"
if [ -z "$DAEMON_BIN" ] || [ ! -x "$DAEMON_BIN" ]; then
    DAEMON_BIN="$(find_binary "$DAEMON" $BIN_CANDIDATES)" || fail "failed to locate $DAEMON binary" ""
fi

rm -rf "$DATA_DIR"
mkdir -p "$DATA_DIR"
LOG="$DATA_DIR/${DAEMON}.log"
rm -f "$LOG"

export SEED_PMM_DB="$DATA_DIR/pmm.db"
export SEED_POOL_DB="${SEED_POOL_DB:-$DATA_DIR/seedpool.leases}"

case "$DAEMON" in
    orchestrator)
        AGENTS="${SEED_ORCH_AGENTS:-seed.agent.solace,seed.agent.pareon}"
        TICKS="${SEED_ORCH_TICKS:-3}"
        ;;
    seedfsd)
        mkdir -p "$DATA_DIR/state"
        ;;
esac

set -- "$DAEMON_BIN" --port 0 --log-file "$LOG" --offline

case "$DAEMON" in
    orchestrator)
        set -- "$@" --ticks "$TICKS" --agents "$AGENTS"
        ;;
esac

for arg in $EXTRA_ARGS; do
    set -- "$@" "$arg"
done

start_time=$(date +%s 2>/dev/null || echo 0)

(
    cd "$DATA_DIR"
    exec "$@"
) &
DAEMON_PID=$!

if ! kill -0 "$DAEMON_PID" 2>/dev/null; then
    fail "$DAEMON failed to start" ""
fi

PORT=0
extract_port() {
    if [ ! -f "$LOG" ]; then
        return 1
    fi
    line="$(grep -m1 '\"listener started\"' "$LOG" || true)"
    if [ -z "$line" ]; then
        return 1
    fi
    maybe_port="$(printf '%s\n' "$line" | sed -E 's/.*\"port\":\"?([0-9]+)\"?.*/\1/')" || true
    if [ -n "$maybe_port" ] && printf '%s' "$maybe_port" | grep -Eq '^[0-9]+$'; then
        PORT="$maybe_port"
        return 0
    fi
    return 1
}

for _ in $(seq 1 40); do
    extract_port && break
    sleep 0.1
done

if [ "$PORT" -eq 0 ]; then
    log_snip="$(tail -n 50 "$LOG" 2>/dev/null || true)"
    fail "failed to discover $DAEMON port" "$log_snip"
fi

if command -v curl >/dev/null 2>&1; then
    probe_health() {
        curl -fsS "http://127.0.0.1:$PORT/health" >/dev/null
    }
else
    probe_health() {
        python3 - <<PY
import sys
import urllib.request
try:
    urllib.request.urlopen("http://127.0.0.1:$PORT/health", timeout=2)
    sys.exit(0)
except Exception as exc:
    print(f"health probe failed: {exc}", file=sys.stderr)
    sys.exit(1)
PY
    }
fi

success=0
for _ in $(seq 1 20); do
    if ! kill -0 "$DAEMON_PID" 2>/dev/null; then
        log_snip="$(tail -n 50 "$LOG" 2>/dev/null || true)"
        fail "$DAEMON exited before health check" "$log_snip"
    fi
    if probe_health; then
        success=1
        break
    fi
    sleep 0.1
done

log_snip="$(tail -n 50 "$LOG" 2>/dev/null || true)"

if [ "$success" -ne 1 ]; then
    fail "failed to reach $DAEMON health endpoint on port $PORT" "$log_snip"
fi

write_junit_success

exit 0
