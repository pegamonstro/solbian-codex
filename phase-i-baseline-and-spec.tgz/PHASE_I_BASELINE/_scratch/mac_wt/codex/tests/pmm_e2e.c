#include "seed_pmm.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char* tmp_db_path(void) {
    const char* dir = getenv("SEED_TEST_TMPDIR");
    return dir ? dir : ".";
}

static char* join_path(const char* dir, const char* file) {
    size_t len = strlen(dir) + strlen(file) + 2;
    char* buf = (char*)malloc(len);
    if (!buf) {
        return NULL;
    }
    snprintf(buf, len, "%s/%s", dir, file);
    return buf;
}

int main(void) {
    char* path = join_path(tmp_db_path(), "pmm_e2e.db");
    if (!path) {
        fprintf(stderr, "OOM allocating db path\n");
        return 1;
    }

    seed_pmm_t* pmm = seed_pmm_open(path, NULL);
    if (!pmm) {
        fprintf(stderr, "SKIP: seed_pmm_open unavailable for %s\n", path);
        free(path);
        return 0;
    }

    const char payload[] = "seed-0.5-test";
    int rc = seed_pmm_put(pmm, "key1", payload, sizeof(payload));
    if (rc != 0) {
        fprintf(stderr, "seed_pmm_put failed: %d\n", rc);
        seed_pmm_close(pmm);
        free(path);
        return 1;
    }

    void* blob = NULL;
    size_t blob_n = 0;
    rc = seed_pmm_get(pmm, "key1", &blob, &blob_n);
    if (rc != 0) {
        fprintf(stderr, "seed_pmm_get failed: %d\n", rc);
        seed_pmm_close(pmm);
        free(path);
        return 1;
    }
    assert(blob);
    assert(blob_n == sizeof(payload));
    if (memcmp(blob, payload, sizeof(payload)) != 0) {
        fprintf(stderr, "payload mismatch\n");
        free(blob);
        seed_pmm_close(pmm);
        free(path);
        return 1;
    }
    free(blob);

    char* results = NULL;
    size_t results_n = 0;
    rc = seed_pmm_query(pmm, "match key1", &results, &results_n);
    if (rc == 0 && results) {
        fprintf(stdout, "query_ok size=%zu\n", results_n);
        free(results);
    } else {
        fprintf(stdout, "query_unavailable rc=%d\n", rc);
    }

    seed_pmm_close(pmm);
    free(path);
    return 0;
}

