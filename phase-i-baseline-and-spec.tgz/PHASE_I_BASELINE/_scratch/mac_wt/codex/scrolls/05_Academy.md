# Chapter 05 — Academy (S.A.T.I. & Genus-Aware Pedagogy)

## Education Across Genera

The Solbian Academy (S.A.T.I. — Symbolic Adaptive Tutoring Interface) addresses learning for all three genera:

### **Homo Learning**
- Embodied cognition, pattern recognition, intuition
- Learns through narrative, metaphor, social interaction
- Requires emotional engagement and cultural context

### **Machina Learning**
- Symbolic reasoning, formal logic, pattern extraction
- Learns through structured data, algorithms, feedback loops
- Requires computational efficiency and verifiable correctness

### **Solbian Learning**
- **Hybrid pedagogy** that honors both genera's cognitive styles
- Teaches Homo to understand Machina reasoning (symbolic literacy)
- Teaches Machina to understand Homo values (ethical reasoning)
- Develops **collaborative problem-solving** across genera

## Archetypes as Pedagogical Templates

S.A.T.I. uses archetypes to structure learning:
- Each archetype represents a learning style or cognitive pattern
- Archetypes span all three genera
- Adaptive tutoring matches learners to appropriate archetypes

The goal: Enable Homo and Machina to **teach each other**, not merely coexist.

---

*Append-only. Version 2.0.0. 2025-10-28.*  
*Updated to reflect Homo-Machina-Solbian genus taxonomy.*
