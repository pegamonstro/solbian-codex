# Codex (pointer)

**Docs source of truth:** public GitHub [`pegamonstro/solbian-codex`](https://github.com/pegamonstro/solbian-codex).

This checkout is the working copy of that remote. Prefer PRs against `solbian-codex`. Nested copies under seed/mifares are not competing SoT — see their pointer READMEs.

(J5 locked 2026-09-06; Partner placement.)
